CREATE TABLE user (
    id INT(11) PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);
INSERT user VALUES (1, 'Masato Taruishi');
